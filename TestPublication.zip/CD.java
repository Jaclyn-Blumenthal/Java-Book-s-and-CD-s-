public class CD extends Publication {
   int minutes;

   public CD(String title, double price, int year, int minutes) {
       super(title, price, year);
       // TODO Auto-generated constructor stub
       this.minutes = minutes;
   }

   @Override
   public void use() {
       // TODO Auto-generated method stub
       System.out.println("Look on CD to find topic number.");

   }

   @Override
   public void print() {
     System.out.println("CD"); ////outputs CD on top when choose cd
       // TODO Auto-generated method stub
       super.print();
       System.out.println("Number of minutes is " + minutes);
       System.out.println("Skip to corresponding section.");
   }

}