public abstract class Publication {

   String title;
   double price;
   int year;

   /**
   * @param title
   * @param price
   * @param year
   */
   public Publication(String title, double price, int year) {

       this.title = title;
       this.price = price;
       this.year = year;
   }

   /**
   * @param percent
   */
      public void raisePrice(int percent) {

       price = price + (price * ((double) percent / 100.00));

   }

   /**
   * method to print the publication object
   */
   public void print() {

       System.out.printf("Title is %s\n ", title);
       System.out.printf("Price is %.2f\n ", price);
       System.out.printf("The publication year is %d\n ", year);
   }

   public abstract void use();

}