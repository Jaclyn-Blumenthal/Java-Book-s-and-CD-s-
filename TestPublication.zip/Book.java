public class Book extends Publication {
   int numberOfPages;

   public Book(String title, double price, int year, int numberOfPages) {
       super(title, price, year);
       // TODO Auto-generated constructor stub

       this.numberOfPages = numberOfPages;
   }

   @Override
   public void use() //
   {
       // TODO Auto-generated method stub
     System.out.println("Open book to table of Contents."); //outputs open book to tabel of contents
     System.out.println("Look up topic and turn to corresponding Page.");//outputs lookup topic and turn to corresponding page

   }

   @Override
   public void print() {
     System.out.println("Book");//outputs Book on top when book is chosen
       // TODO Auto-generated method stub
       super.print(); //calling the print function from the super class
       System.out.println("Number of Pages is " + numberOfPages); //outputs the number of pages

   }

}

