import java.util.Scanner;
import java.io.*;

/**
* @author Srinivas
*
*/
public class TestPublication 

{

   /**
   * @param args
   */
   public static void main(String[] args) throws IOException 
   {
         Scanner scanner = new Scanner(System.in);
         BufferedReader br = new BufferedReader(new InputStreamReader (System.in));
        
         
         System.out.print("Enter number of Publications: ");
           int noofPub = scanner.nextInt();
           Publication publication[] = new Publication[noofPub];
           for (int i = 0; i < publication.length; i++) 
           {
             System.out.print("Enter Title: ");
                    
           String title = br.readLine();
           System.out.print("Enter price: ");
           double price = scanner.nextDouble();
                   
           System.out.print("Enter publication year: ");
           int year = scanner.nextInt();
                   

          System.out.print("Is the Publication a Book (b) or CD (c))? ");
               String typeOfPub = br.readLine();
              
               if (typeOfPub.equalsIgnoreCase("C")) 
               {

                   System.out.print("Enter the minutes: ");
                   int minutes = scanner.nextInt();
                   publication[i] = new CD(title, price, year, minutes);
               } 
               else if (typeOfPub.equalsIgnoreCase("b"))
               {

                   System.out.print("Enter the Pages: ");
                   int pages = scanner.nextInt();
                   publication[i] = new Book(title, price, year, pages);
               }
           }
               // calling raise()
               for (int i = 0; i < noofPub; i++) {
             System.out.println();
                 publication[i].raisePrice(10); 
               publication[i].print();
               publication[i].use();
         
               }
   }
}
  

           
       

           

        
           // TODO: handle exception
       
           
       
   
